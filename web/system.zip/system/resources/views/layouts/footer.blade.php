{{-- footer web --}}
<style>
    footer div {
        margin-top: 5px;
        background: rgba(40,40,40,1);
        padding: 10px;
        letter-spacing: 2px;
        color: rgba(255, 255, 255, 1);
    }
</style>
<div class="container-fluid text-center">
    &copy; VDI 2016
</div>
