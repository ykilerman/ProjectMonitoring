{{-- footer web --}}
<style>
    footer div {
        margin-top: 5px;
        background: radial-gradient(rgba(0,0,255,0.1), rgba(0,0,255,0.4));
/*        background: linear-gradient(to bottom, rgba(0,0,255,0.1), rgba(0,0,255,0.4));*/
/*        background-color: rgba(0,0,0,0.2);*/
        padding: 10px;
        letter-spacing: 2px;
    }
</style>
<div class="container-fluid text-center">
    &copy; VDI 2016
</div>
