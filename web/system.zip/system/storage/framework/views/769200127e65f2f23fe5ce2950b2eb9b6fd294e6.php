<?php $__env->startSection('title'); ?> Detail Report | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(Session::has('message')): ?>
    <div id="error" class="alert alert-success">
        <p><?php echo e(Session::get('message')); ?></p>
        <p><i>Click to hide this message.</i></p>
    </div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-3">
        <figure>
            <img class="img-responsive" src="<?php echo e($report->project->icon_path); ?>">
        </figure>
    </div>
    <div class="col-lg-9">
        <p>Project Name : <a href="<?php echo e(url('project/detail?id='.$report->project_id)); ?>"><strong><big><?php echo e($report->project->name); ?></big></strong></a></p>
        <p>Project Time : <?php echo e(date_format($report->project->created_at,'d M Y - H:i:s')); ?></p>
        <p>Project Cost : Rp<?php echo e(number_format($report->project->value,0,',','.')); ?></p>
        <p>Project Coordinator : <?php echo e($report->project->user->name); ?></p>
        <p>Client Name : <?php echo e($report->project->client_name); ?></p>
        <p>Project Type : <?php echo e($report->project->type); ?></p>
    </div>
</div>
<h3>Report <?php echo e(date_format($report->created_at,'d M Y - H:i:s')); ?></h3>
<div class="row">
    <div class="col-lg-12">
        <h3>Highlight:</h3>
        <p><?php echo e($report->highlight); ?></p>
    </div>
    <div class="col-lg-4">
        <h3>Activity:</h3>
        <p><?= $report->activity ?></p>
        <h4>Evidence:</h4>
        <figure>
            <img src="<?php echo e($report->activity_path); ?>" class="img-responsive">
        </figure>
    </div>
    <div class="col-lg-4">
        <h3>Income:</h3>
        <p><?= $report->income ?></p>
        <h4>Evidence:</h4>
        <figure>
            <img src="<?php echo e($report->income_path); ?>" class="img-responsive">
        </figure>
    </div>
    <div class="col-lg-4">
        <h3>Expense:</h3>
        <p><?= $report->expense ?></p>
        <h4>Evidence:</h4>
        <figure>
            <img src="<?php echo e($report->expense_path); ?>" class="img-responsive">
        </figure>
    </div>
</div>
<p>
    <button onclick="javascript:history.back()" class="btn btn-lg btn-info">Back</button>
</p>

<script>
    $(document).ready(function(){
        $("#error").click(function(){
            $(this).hide('slow');
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>