<?php $__env->startSection('title'); ?> New Report | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                New Report for <b><?php echo e($project->name); ?></b>
            </div>
            <div class="panel-body">
                <?php echo e(Form::open(['url'=>url('report/create'),'method'=>'POST','id'=>'frmReportAdd','class'=>'form-horizontal','files'=>'true'])); ?>

                    <?php echo e(Form::hidden('project_id',$project->id)); ?>

                    <?php if(count($errors)>0): ?>
                        <div id="error" class="alert alert-danger">
                            <?php foreach($errors->all() as $error): ?>
                                <p><?php echo e($error); ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('message')): ?>
                        <div id="error" class="alert alert-danger">
                            <p><?php echo e(Session::get('message')); ?></p>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <?php echo e(Form::label('highlight','Highlight',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('highlight',old('highlight'),['class'=>'form-control','placeholder'=>'Insert Report Highlight ...','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('activity','Activity',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::textarea('activity',old('activity'),['class'=>'form-control','placeholder'=>'Insert Report Activity ...','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('activity_path','Activity Evidence',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::file('activity_path')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('income','Income',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::number('income',old('income'),['class'=>'form-control','placeholder'=>'0'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('income_path','Income Evidence',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::file('income_path')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('expense','Expense',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::number('expense',old('expense'),['class'=>'form-control','placeholder'=>'0'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('expense_path','Expense Evidence',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::file('expense_path')); ?>

                        </div>
                    </div>
                    <div class="col-sm-offset-3 col-sm-2">
                        <?php echo e(Form::submit('Save',['class'=>'btn btn-primary btn-block','id'=>'btnSave'])); ?>

                    </div>
                    <div class="col-sm-2">
                        <button onclick="javascript:history.back()" class="btn btn-primary btn-block">Back</button>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("#error").click(function(){
            $(this).hide('slow');
        });
    });
</script>
<hr>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>