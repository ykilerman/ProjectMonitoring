<?php $__env->startSection('title'); ?> Login | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-4 col-lg-offset-4">
        <div class="panel panel-danger">
            <div class="panel-heading">
                <i class="glyphicon glyphicon-user"></i> Login
                <?php if(Session::has('message')): ?>
                    <span class="label <?php echo e(Session::get('type')); ?>"><?php echo e(Session::get('message')); ?></span>
                <?php endif; ?>
            </div>
            <div class="panel-body">
                <?php echo e(Form::open(['url' => url('login'),'method'=>'POST','role'=>'form','class'=>'form-horizontal'])); ?>

                <div class="form-group">
                    <?php echo e(Form::label('username','Username',['class'=>'control-label col-lg-3'])); ?>

                    <div class="col-lg-9">
                        <?php echo e(Form::text('username',old('username'),['class'=>'form-control','autofocus'])); ?>

                    </div>
                </div>
                <div class="form-group">
                    <?php echo e(Form::label('password','Password',['class'=>'control-label col-lg-3'])); ?>

                    <div class="col-lg-9">
                        <?php echo e(Form::password('password',['class'=>'form-control'])); ?>

                    </div>
                </div>
                <div class="form-group">
                    <div class="col-lg-offset-3 col-lg-9">
                        <?php echo e(Form::checkbox('remember')); ?> Remember Me
                    </div>
                </div>
                <div class="col-lg-offset-3 col-lg-4">
                    <?php echo e(Form::submit('Login',['class' => 'btn btn-danger'])); ?>

                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>