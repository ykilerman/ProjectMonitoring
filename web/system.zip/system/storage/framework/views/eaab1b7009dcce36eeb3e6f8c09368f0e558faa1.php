<?php $__env->startSection('title'); ?> Month Report | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$now = date('Y');
?>
<h2>
    Month Report
</h2>
<hr>
<div class="row form-group">
    <?php echo e(Form::label('month','Select Month',['class' => 'control-label col-lg-2'])); ?>

    <div class="col-lg-2">
        <?php echo e(Form::selectMonth('month',Session::get('report_month'),['class' => 'form-control', 'id' => 'selectMonth'])); ?>

    </div>
    <div class="col-lg-2">
        <?php echo e(Form::selectRange('year', $now, $now-15, Session::get('report_year'), ['class' => 'form-control', 'id' => 'selectYear'])); ?>

    </div>
</div>
<?php if(Session::has('message')): ?>
    <div id="message" class="alert alert-success">
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<div id="data"></div>

<script>
    $(document).ready(function(){
        ajaxLoad("<?php echo e(url('report/listmonth')); ?>",'data');

        $("#message").click(function(){
            $(this).hide('slow');
        });
        $("#selectMonth").change(function(){
            ajaxLoad("<?php echo e(url('report/listmonth?month=')); ?>" + $(this).val(), 'data');
        });
        $("#selectYear").change(function(){
            ajaxLoad("<?php echo e(url('report/listmonth?year=')); ?>" + $(this).val(), 'data');
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>