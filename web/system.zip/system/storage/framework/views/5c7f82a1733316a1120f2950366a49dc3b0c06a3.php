<?php $__env->startSection('title'); ?> Change Password | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h2>
    Change Password
</h2>
<hr>
<?php if(Session::has('message')): ?>
    <div id="message" class="alert alert-success">
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<?php echo e(Form::open(['url' => url('changepassword'),'method'=>'POST','class'=>'form-horizontal'])); ?>

    <?php if(count($errors) > 0): ?>
        <div id="error" class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <p><strong><?php echo e($error); ?></strong></p>
            <?php endforeach; ?>
            <p><i>Click to close the alert.</i></p>
        </div>
    <?php endif; ?>
    <div class="form-group">
        <?php echo e(Form::label('oldpass','Old Password',['class'=>'col-lg-2 control-label'])); ?>

        <div class="col-lg-4">
            <?php echo e(Form::password('oldpass',['class'=>'form-control'])); ?>

        </div>
    </div>
    <div class="form-group">
        <?php echo e(Form::label('newpass','New Password',['class'=>'col-lg-2 control-label'])); ?>

        <div class="col-lg-4">
            <?php echo e(Form::password('newpass',['class'=>'form-control'])); ?>

        </div>
    </div>
    <div class="form-group">
        <?php echo e(Form::label('renewpass','Re-New Password',['class'=>'col-lg-2 control-label'])); ?>

        <div class="col-lg-4">
            <?php echo e(Form::password('renewpass',['class'=>'form-control'])); ?>

        </div>
    </div>
    <div class="col-lg-offset-2 col-lg-2">
        <?php echo e(Form::submit('Change',['class'=>'btn btn-danger btn-block','id'=>'btnSave'])); ?>

    </div>
<?php echo e(Form::close()); ?>


<script>
    $(document).ready(function(){
        $("#message").click(function(){
            $(this).hide('slow');
        });
        $("#error").click(function(){
            $(this).hide('slow');
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>