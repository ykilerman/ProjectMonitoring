<?php $__env->startSection('title'); ?> Report List | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-2">
        <img class="img-responsive" src="<?php echo e($project->icon_path); ?>" />
    </div>
    <div class="col-lg-10">
        <h2><?php echo e($project->name); ?></h2>
    </div>
</div>
<h2>
    Report List
</h2>
<?php if(Session::has('message')): ?>
    <div id="message" class="alert alert-success">
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<div id="data"></div>

<script>
    $(document).ready(function(){
        ajaxLoad("<?php echo e(url('report/listreport?id='.$project->id)); ?>",'data');

        $("#message").click(function(){
            $(this).hide('slow');
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>