<?php $__env->startSection('title'); ?> Detail Project | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h2>Project Detail</h2>
<?php if(Session::has('message')): ?>
    <div id="error" class="alert alert-success">
        <p><?php echo e(Session::get('message')); ?></p>
        <p><i>Click to hide this message.</i></p>
    </div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-3">
        <figure >
            <img class="img-responsive" src="<?php echo e($project->icon_path); ?>">
        </figure>
    </div>
    <div class="col-lg-9">
        <p>Project Name : <strong><big><?php echo e($project->name); ?></big></strong></p>
        <p>Project Time : <?php echo e(date_format($project->created_at,'d M Y - H:i')); ?></p>
        <p>Project Cost : Rp<?php echo e(number_format($project->value,0,',','.')); ?></p>
        <p>Project Coordinator : <?php echo e($project->user->name); ?></p>
        <p>Client Name : <?php echo e($project->client_name); ?></p>
        <p>Project Type : <?php echo e($project->type); ?></p>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <p>Project Description : </p>
        <?= $project->description ?>
    </div>
</div>
<hr>
<button class="btn btn-danger" id="btnEdit">Edit Project Detail</button>
<button class="btn btn-danger" id="btnBack">Back</button>
<hr>
<h3>Report</h3>
<p><a href="<?php echo e(url('report?id='.$project->id)); ?>" class="link">View <strong><?php echo e($project->name); ?></strong>'s reports here</a></p>
<hr>
<h3>Question & Answer</h3>
<div id="question"></div>

<script>
    $(document).ready(function(){
        ajaxLoad("<?php echo e(url('question/list?project_id='.$project->id)); ?>",'question');
        $("#btnBack").click(function(){
            history.back();
        });
        $("#btnEdit").click(function(){
            window.location.href = '<?php echo e(url('project/edit?id='.$project->id)); ?>';
        });
        $("#error").click(function(){
            $(this).hide('slow');
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>