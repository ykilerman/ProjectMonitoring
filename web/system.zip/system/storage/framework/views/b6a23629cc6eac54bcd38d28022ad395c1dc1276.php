<?php $__env->startSection('title'); ?> Notification | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    use App\Report;
    use App\Project;
    use App\Answer;
    use App\Question;
?>
<style>
    tbody tr:hover {
        cursor: pointer;
    }
</style>
<h2>
    Notification
</h2>
<hr>
<?php if(Session::has('message')): ?>
    <div id="message" class="alert alert-success">
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<table class="table table-hover table-striped table-bordered">
    <thead>
        <td>Time</td>
        <td>Notification</td>
    </thead>
    <tbody>
        <?php foreach($notifications as $notification): ?>
            <?php if($notification->table == 'reports'): ?>
                <?php
                    $data = Report::find($notification->table_id);
                ?>
                <tr onclick="javascript: window.location.href = '<?php echo e(url('report/detail?id='.$data->id)); ?>';">
                    <td><?php echo e($data->created_at); ?></td>
                    <td>New report for project <b><?php echo e($data->project->name); ?></b></td>
                </tr>
            <?php elseif($notification->table == 'projects'): ?>
                <?php
                    $data = Project::find($notification->table_id);
                ?>
                <tr onclick="javascript: window.location.href = '<?php echo e(url('project/detail?id='.$data->id)); ?>';">
                    <td><?php echo e($data->created_at); ?></td>
                    <td>New project is created: <b><?php echo e($data->name); ?></b></td>
                </tr>
            <?php elseif($notification->table == 'questions'): ?>
                <?php
                    $data = Question::find($notification->table_id);
                ?>
                <tr onclick="javascript: window.location.href = '<?php echo e(url('project/detail?id='.$data->project_id)); ?>';">
                    <td><?php echo e($data->created_at); ?></td>
                    <td>New question for project <b><?php echo e($data->project->name); ?></b>: <?php echo e($data->text); ?></td>
                </tr>
            <?php elseif($notification->table == 'answers'): ?>
                <?php
                    $data = Answer::find($notification->table_id);
                ?>
                <tr onclick="javascript: window.location.href = '<?php echo e(url('project/detail?id='.$data->question->project_id)); ?>';">
                    <td><?php echo e($data->created_at); ?></td>
                    <td>New question for project <b><?php echo e($data->question->project->name); ?></b>: <?php echo e($data->text); ?></td>
                </tr>
            <?php endif; ?>
        <?php endforeach; ?>
    </tbody>
</table>
<script>
    $(document).ready(function(){
        $("#message").click(function(){
            $(this).hide('slow');
        });
        $("#error").click(function(){
            $(this).hide('slow');
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>