<style>
    tbody tr:hover{
        cursor: pointer;
    }
</style>
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover text-center">
        <thead>
            <td>
                Time
            </td>
            <td>
                To
            </td>
            <td>
                Subject
            </td>
            <td>
                Action
            </td>
        </thead>
        <tbody>
            <?php foreach($messages as $message): ?>
                <tr onclick="javascript:window.location.href='<?php echo e(url('message/detail?id='.$message->id)); ?>'">
                    <td><?php echo e($message->updated_at); ?></td>
                    <td>
                        <?php foreach($message->messageDetail as $detail): ?>
                            <?php echo e($detail->user->name . ', '); ?>

                        <?php endforeach; ?>
                    </td>
                    <td><?php echo e($message->subject); ?></td>
                    <td><a href="<?php echo e(url('message/detail?id='.$message->id)); ?>">View Detail</a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p>
        Total Data : <?php echo e($total); ?>

        <div class="pull-right"><?php echo str_replace('/?','?',$messages->render()); ?></div>
    </p>
</div>
<script>
    $('.pagination a').on('click', function (event) {
        event.preventDefault();
        ajaxLoad($(this).attr('href'),'data');
    });
</script>
