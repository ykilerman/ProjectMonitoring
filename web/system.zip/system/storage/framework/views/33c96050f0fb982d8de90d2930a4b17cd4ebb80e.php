<?php $__env->startSection('title'); ?> New Projects | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php
$user = [];
foreach($users as $data)
{
    $user += [$data->id => $data->name];
}
?>
<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                New Project
            </div>
            <div class="panel-body">
                <?php echo e(Form::open(['url'=>url('project/create'),'method'=>'POST','id'=>'frmProjectAdd','class'=>'form-horizontal','files'=>'true'])); ?>

                    <?php if(count($errors)>0): ?>
                        <div id="error" class="alert alert-danger">
                            <?php foreach($errors->all() as $error): ?>
                                <p><?php echo e($error); ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <?php echo e(Form::label('name','Project Name',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('name',old('name'),['class'=>'form-control','placeholder'=>'Insert Project Name ...','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('user_id','Project Coordinator',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php if(Auth::user()->position == 'Project Coordinator'): ?>
                                <?php echo e(Form::select('user_id',$user,Auth::user()->id,['class'=>'form-control','placeholder' => 'Select Project Coordinator ...'])); ?>

                            <?php else: ?>
                                <?php echo e(Form::select('user_id',$user,old('user_id'),['class'=>'form-control','placeholder' => 'Select Project Coordinator ...'])); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('description','Description',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::textarea('description',old('description'),['class'=>'form-control','placeholder'=>'Insert Description ...','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('icon_path','Icon Project',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::file('icon_path')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('client_name','Client Name',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('client_name',old('client_name'),['class'=>'form-control','placeholder'=>'Insert Client Name ...','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('value','Project Cost',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::number('value',old('value'),['class'=>'form-control','placeholder'=>'Insert Project Cost ...','min'=>'0','max'=>'99999999999','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('update_schedule','Notification Schedule',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::number('update_schedule',old('update_schedule'),['class'=>'form-control','min'=>'0','max'=>'999','placeholder' => 'Insert Notification Schedule ...','required'])); ?>

                        </div>
                    </div>
                    <div class="col-sm-offset-3 col-sm-2">
                        <?php echo e(Form::submit('Save',['class'=>'btn btn-primary btn-block','id'=>'btnSave'])); ?>

                    </div>
                    <div class="col-sm-2">
                        <a href="<?php echo e(url('project')); ?>" class="btn btn-info btn-block">Cancel</a>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("#error").click(function(){
            $(this).hide('slow');
        });
    });
</script>
<hr>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>