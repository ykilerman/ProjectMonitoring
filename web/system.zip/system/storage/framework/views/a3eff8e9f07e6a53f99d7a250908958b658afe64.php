<?php $__env->startSection('title'); ?> Select Project | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h2>
    Select Project
</h2>
<hr>
<div class="row">
    <div class="col-lg-4 form-group">
        <div class="input-group">
            <input class="form-control" id="search" value="<?php echo e(Session::get('report_search')); ?>"
                   onkeyup="if ((event.keyCode >= 48 && event.keyCode <= 90) || event.keyCode == 13 || event.keyCode == 8 || event.keyCode == 46) ajaxLoad('<?php echo e(url('report/listproject')); ?>?ok=1&search='+this.value,'data')"
                   placeholder="Find name ..."
                   type="text"
                   autofocus>
            <div class="input-group-btn">
                <button type="button" class="btn btn-default"
                        onclick="ajaxLoad('<?php echo e(url('report/listproject')); ?>?ok=1&search='+$('#search').val())"><i
                            class="glyphicon glyphicon-search"></i>
                </button>
            </div>
        </div>
    </div>
</div>
<?php if(Session::has('message')): ?>
    <div id="message" class="alert alert-success">
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<div id="data"></div>

<script>
    $(document).ready(function(){
        ajaxLoad("<?php echo e(url('report/listproject')); ?>",'data');

        $("#message").click(function(){
            $(this).hide('slow');
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>