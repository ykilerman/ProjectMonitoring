@extends('layouts.app')

@section('title') contoh | @endsection

@section('content')

{{-- place your content here --}}
tes

@endsection
