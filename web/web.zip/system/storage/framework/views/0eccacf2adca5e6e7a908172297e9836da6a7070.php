<?php $__env->startSection('title'); ?> Edit Project | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php
$user = [];
foreach($users as $data)
{
    $user += [$data->id => $data->name];
}
?>
<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-danger">
            <div class="panel-heading">
                Edit Project
            </div>
            <div class="panel-body">
                <?php echo e(Form::open(['url'=>url('project/edit'),'method'=>'POST','id'=>'frmProject','class'=>'form-horizontal','files'=>'true'])); ?>

                    <?php echo e(Form::hidden('id',$project->id)); ?>

                    <?php if(count($errors)>0): ?>
                        <div id="error" class="alert alert-danger">
                            <?php foreach($errors->all() as $error): ?>
                                <p><?php echo e($error); ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <?php echo e(Form::label('name','Project Name',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('name',$project->name,['class'=>'form-control','placeholder'=>'Insert Project Name ...','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('type','Project Type',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::select('type',['Consultation' => 'Consultation', 'Procurement' => 'Procurement', 'Consultation and Procurement' => 'Consultation and Procurement'],$project->type,['class'=>'form-control','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('user_id','Project Coordinator',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::select('user_id',$user,$project->user_id,['class'=>'form-control','placeholder' => 'Select Project Coordinator ...'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('description','Description',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::textarea('description',$project->description,['class'=>'form-control','placeholder'=>'Insert Description ...','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('icon_path','Icon Project',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::file('icon_path')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('client_name','Client Name',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('client_name',$project->client_name,['class'=>'form-control','placeholder'=>'Insert Client Name ...','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('value','Project Cost',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::number('value',$project->value,['class'=>'form-control','placeholder'=>'Insert Project Cost ...','min'=>'0','max'=>'99999999999','required'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('update_schedule','Notification Schedule',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::number('update_schedule',$project->update_schedule,['class'=>'form-control','min'=>'0','max'=>'999','placeholder' => 'Insert Notification Schedule ...','required'])); ?>

                        </div>
                    </div>
                    <div class="col-sm-offset-3 col-sm-2">
                        <?php echo e(Form::submit('Save',['class'=>'btn btn-danger btn-block','id'=>'btnSave'])); ?>

                    </div>
                    <div class="col-sm-2">
                        <button id="btnBack" class="btn btn-info btn-block" onclick="javascript:history.back()">Back</a>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("#error").click(function(){
            $(this).hide('slow');
        });
    });
</script>
<hr>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>