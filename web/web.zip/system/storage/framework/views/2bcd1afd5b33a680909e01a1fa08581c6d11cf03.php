<ul>
<?php foreach($answers as $answer): ?>
    <li><h4><?= $answer->text ?> <small> - <?php echo e($answer->user->name); ?>, <?php echo e(date_format($answer->created_at,'d/m/y H:i')); ?></small></h4></li>
<?php endforeach; ?>
</ul>