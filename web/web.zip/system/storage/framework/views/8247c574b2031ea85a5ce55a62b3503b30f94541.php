<?php $__env->startSection('title'); ?> Quarterly Report | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    $now = date('Y');
?>
<h2>
    Quarterly Report
</h2>
<hr>
<div class="row form-group">
    <?php echo e(Form::label('month','Select Quarter',['class' => 'control-label col-lg-2'])); ?>

    <div class="col-lg-3">
        <?php echo e(Form::select('quarter', ['January - March', 'April - June', 'July - September', 'October - December'],Session::get('report_quarter'),['class' => 'form-control', 'id' => 'selectQuarter'])); ?>

    </div>
    <div class="col-lg-2">
        <?php echo e(Form::selectRange('year', $now, $now-15, Session::get('report_year'), ['class' => 'form-control', 'id' => 'selectYear'])); ?>

    </div>
</div>
<?php if(Session::has('message')): ?>
    <div id="message" class="alert alert-success">
        <?php echo e(Session::get('message')); ?>

    </div>
<?php endif; ?>
<div id="data"></div>

<script>
    $(document).ready(function(){
        ajaxLoad("<?php echo e(url('report/listquarterly')); ?>",'data');

        $("#message").click(function(){
            $(this).hide('slow');
        });
        $("#selectQuarter").change(function(){
            ajaxLoad("<?php echo e(url('report/listquarterly?quarter=')); ?>" + $(this).val(), 'data');
        });
        $("#selectYear").change(function(){
            ajaxLoad("<?php echo e(url('report/listquarterly?year=')); ?>" + $(this).val(), 'data');
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>