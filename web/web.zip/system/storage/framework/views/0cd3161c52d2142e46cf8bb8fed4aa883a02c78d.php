<?php foreach($notifications as $notification): ?>
    <?php if($notification->table == 'projects'): ?>
        <li><a href="<?php echo e(url('project/detail?id='.$notification->table_id)); ?>">On Going Project</a></li>
    <?php elseif($notification->table == 'reports'): ?>
        <li><a href="<?php echo e(url('project/detail?id='.$notification->table_id)); ?>">On Going Project</a></li>
    <?php elseif($notification->table == 'questions'): ?>
        <li><a href="<?php echo e(url('project/detail?id='.$notification->table_id)); ?>">On Going Project</a></li>
    <?php elseif($notification->table == 'answers'): ?>
        <li><a href="<?php echo e(url('project/detail?id='.$notification->table_id)); ?>">On Going Project</a></li>
    <?php endif; ?>
<?php endforeach; ?>