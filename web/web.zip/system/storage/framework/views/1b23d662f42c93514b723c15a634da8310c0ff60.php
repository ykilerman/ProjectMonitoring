<?php
$user = [];
foreach($users as $data)
{
    $user += [$data->id => $data->name];
}
?>
<div class="form-group">
    <?php echo e(Form::label('user_id','Project Coordinator',['class'=>'col-sm-3 control-label'])); ?>

    <div class="col-sm-9">
        <?php if(Auth::user()->position == 'Project Coordinator'): ?>
            <?php echo e(Form::select('user_id',$user,Auth::user()->id,['class'=>'form-control','placeholder' => 'Select Project Coordinator ...'])); ?>

        <?php else: ?>
            <?php echo e(Form::select('user_id',$user,old('update_schedule'),['class'=>'form-control','placeholder' => 'Select Project Coordinator ...'])); ?>

        <?php endif; ?>
    </div>
    <?php if($errors->has()): ?>
        <span class="label label-danger"><?php echo e($errors->first('user_id')); ?></span>
    <?php endif; ?>
</div>
