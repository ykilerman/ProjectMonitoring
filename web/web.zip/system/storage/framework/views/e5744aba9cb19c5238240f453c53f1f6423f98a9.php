<style>
    tbody tr:hover{
        cursor: pointer;
    }
</style>
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover text-center">
        <thead>
            <td>
                #
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('report/listquarterly?field=updated_at&sort=<?php echo e(Session::get("report_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Time
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('report_field')=='updated_at'?(Session::get('report_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('report/listquarterly?field=name&sort=<?php echo e(Session::get("report_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Project Name
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('report_field')=='updated_at'?(Session::get('report_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                Highlight
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('report/listquarterly?field=income&sort=<?php echo e(Session::get("report_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Income
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('report_field')=='income'?(Session::get('report_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('report/listquarterly?field=expense&sort=<?php echo e(Session::get("report_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Expense
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('report_field')=='expense'?(Session::get('report_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                Action
            </td>
        </thead>
        <tbody>
            <?php 
                $i = 1;
                $income = 0;
                $expense = 0;
            ?>
            <?php foreach($reports as $report): ?>
                <tr onclick="javascript:window.location.href='<?php echo e(url('report/detail?id='.$report->id)); ?>'">
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($report->created_at); ?></td>
                    <td><?php echo e($report->project->name); ?></td>
                    <td><?php echo e($report->highlight); ?></td>
                    <td><?php echo e($report->income); ?></td>
                    <td><?php echo e($report->expense); ?></td>
                    <td>
                        <a href="<?php echo e(url('report/detail?id='.$report->id)); ?>" class="btn btn-sm btn-danger">View Detail</a>
                    </td>
                </tr>
                <?php
                    $income += $report->income;
                    $expense += $report->expense;
                ?>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <td colspan="4"><div class="pull-right">Total</div></td>
            <td><?php echo e($income); ?></td>
            <td><?php echo e($expense); ?></td>
            <td></td>
        </tfoot>
    </table>
    <p>
        Total Data : <?php echo e($total); ?>

        <div class="pull-right"><?php echo str_replace('/?','?',$reports->render()); ?></div>
    </p>
</div>
<script>
    $('.pagination a').on('click', function (event) {
        event.preventDefault();
        ajaxLoad($(this).attr('href'),'data');
    });
</script>
