<style>
    tbody tr:hover{
        cursor: pointer;
    }
</style>
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover text-center">
        <thead>
            <td>
                #
            </td>
            <td>
                Icon
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('project/list?field=name&sort=<?php echo e(Session::get("project_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Project Name
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('project_field')=='name'?(Session::get('project_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('project/list?field=created_at&sort=<?php echo e(Session::get("project_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Time Created
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('project_field')=='created_at'?(Session::get('project_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                <a onclick="javascript:ajaxLoad('project/list?field=percent&sort=<?php echo e(Session::get("project_sort")=="asc"?"desc":"asc"); ?>','data')" href="#">
                    Progress
                </a>
                <i style="font-size: 12px"
                   class="glyphicon <?php echo e(Session::get('project_field')=='percent'?(Session::get('project_sort')=='asc'?'glyphicon-sort-by-alphabet':'glyphicon-sort-by-alphabet-alt'):''); ?>">
                </i>
            </td>
            <td>
                Action
            </td>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php foreach($projects as $project): ?>
                <?php if((Auth::user()->position == 'Project Coordinator' && $project->user_id == Auth::user()->id) || Auth::user()->position != 'Project Coordinator'): ?>
                    <tr onclick="javascript:window.location.href='<?php echo e(url('project/detail?id='.$project->id)); ?>'">
                        <td><?php echo e($i++); ?></td>
                        <td><img src='<?php echo e($project->icon_path); ?>' width='90px' height="90px" class="img-responsive" alt="" /></td>
                        <td class="text-left"><?php echo e($project->name); ?></td>
                        <td><?php echo e($project->created_at); ?></td>
                        <td><?php echo e($project->percent); ?> %</td>
                        <td><a href="<?php echo e(url('project/detail?id='.$project->id)); ?>">View Detail</a></td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p>
        Total Data : <?php echo e($total); ?>

        <div class="pull-right"><?php echo str_replace('/?','?',$projects->render()); ?></div>
    </p>
</div>
<script>
    $('.pagination a').on('click', function (event) {
        event.preventDefault();
        ajaxLoad($(this).attr('href'),'data');
    });
</script>
