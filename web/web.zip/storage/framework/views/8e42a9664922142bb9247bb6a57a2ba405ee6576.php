<?php /* footer web */ ?>
<div class="container-fluid bg-info text-center">
    Footer Web
</div>
