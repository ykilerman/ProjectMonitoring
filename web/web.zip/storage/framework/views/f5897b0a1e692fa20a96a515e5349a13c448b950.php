<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title><?php echo $__env->yieldContent('title'); ?>Project Monitoring App</title>
    <?php echo e(Html::style(asset('css/bootstrap.min.css'))); ?>

    <?php echo e(Html::style(asset('js/jquery-ui-1.12.0.custom/jquery-ui.min.css'))); ?>

    <?php echo e(Html::script(asset('js/jquery-2.2.3.min.js'))); ?>

    <?php echo e(Html::script(asset('js/bootstrap.min.js'))); ?>

    <?php echo e(Html::script(asset('js/jquery-ui-1.12.0.custom/jquery-ui.min.js'))); ?>

	<style>
        .loading {
            background: lightgoldenrodyellow url('<?php echo e(asset('images/processing.gif')); ?>') no-repeat center 65%;
            height: 80px;
            width: 100px;
            position: fixed;
            border-radius: 4px;
            left: 50%;
            top: 50%;
            margin: -40px 0 0 -50px;
            z-index: 2000;
            display: none;
        }
    </style>
</head>
<body>
    <header><?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></header>
    <div class="container-fluid">
        <div class="row">
            <aside class="col-lg-2 bg-warning"><?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></aside>
            <section class="col-lg-10 bg-success"><?php echo $__env->yieldContent('content'); ?></section>
            <div class="loading"></div>
        </div>
    </div>
    <footer><?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></footer>
</body>
<script>
function ajaxLoad(filename, content) {
	content = typeof content !== 'undefined' ? content : 'content';
	$('.loading').show();
	$.ajax({
		type: "GET",
		url: filename,
		contentType: false,
		success: function (data) {
			$("#" + content).html(data);
			$('.loading').hide();
		},
		error: function (xhr, status, error) {
			alert(xhr.responseText);
		}
	});
}
</script>
</html>
