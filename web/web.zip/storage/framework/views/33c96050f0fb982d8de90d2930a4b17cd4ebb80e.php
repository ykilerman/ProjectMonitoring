<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                New Project
            </div>
            <div class="panel-body">
                <?php echo e(Form::open(['method'=>'POST','id'=>'frmProjectAdd','class'=>'form-horizontal','novalidate'=>"",'files'=>'true'])); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('name','Project Name',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('name',old('name'),['class'=>'form-control','placeholder'=>'Insert Project Name ...'])); ?>

                        </div>
                        <?php if($errors->has()): ?>
                            <span class="label label-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div id="selectUser"></div>
                    <div class="form-group">
                        <?php echo e(Form::label('description','Description',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('description',old('description'),['class'=>'form-control','placeholder'=>'Insert Description ...'])); ?>

                        </div>
                        <?php if($errors->has()): ?>
                            <span class="label label-danger"><?php echo e($errors->first('description')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('icon_path','Icon Project',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::file('icon_path')); ?>

                        </div>
                        <?php if($errors->has()): ?>
                            <span class="label label-danger"><?php echo e($errors->first('icon_path')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('client_name','Client Name',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('client_name',old('client_name'),['class'=>'form-control','placeholder'=>'Insert Client Name ...'])); ?>

                        </div>
                        <?php if($errors->has()): ?>
                            <span class="label label-danger"><?php echo e($errors->first('client_name')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('value','Project Cost',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::number('value',old('value'),['class'=>'form-control','placeholder'=>'Insert Project Cost ...','min'=>'0','max'=>'99999999999'])); ?>

                        </div>
                        <?php if($errors->has()): ?>
                            <span class="label label-danger"><?php echo e($errors->first('value')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('update_schedule','Notification Schedule',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::number('update_schedule',old('update_schedule'),['class'=>'form-control','min'=>'0','max'=>'999','placeholder' => 'Insert Notification Schedule ...'])); ?>

                        </div>
                        <?php if($errors->has()): ?>
                            <span class="label label-danger"><?php echo e($errors->first('update_schedule')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-offset-3 col-sm-2">
                        <?php echo e(Form::button('Save',['class'=>'btn btn-primary btn-block','id'=>'btnSave'])); ?>

                    </div>
                    <div class="col-sm-2">
                        <?php echo e(Form::button('Cancel',['class'=>'btn btn-info btn-block','id'=>'btnCancel'])); ?>

                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<script>
ajaxLoad('<?php echo e(url('project/userlistselect')); ?>','selectUser');
$("#btnCancel").click(function(e){
    $("#new").fadeOut('slow');
});
$(document).ready(function(){
    $("#btnSave").click(function(e){
        e.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        })
        $(".loading").show();
        var formdata = {
            name: $("#name").val(),
            user_id: $("#user_id").val(),
            description: $("#description").val(),
            icon_path: $("#icon_path").val(),
            client_name: $("#client_name").val(),
            value: $("#value").val(),
            update_schedule: $("#update_schedule").val()
        };

        console.log(formdata);

        $.ajax({
            type: "post",
            url: "<?php echo e(url('project/create')); ?>",
            data: formdata,
            success: function(data){
                $("#modalTambah").modal('hide');
                ajaxLoad("<?php echo e(url('project/list')); ?>",'data');
            },
            error: function(data){
                $(".loading").hide();
                console.log("Error: "+data);
            }
        });
    });
});
</script>
<hr>
