<?php /* header web */ ?>
<div class="container-fluid bg-primary text-center">
    Header Web
</div>
