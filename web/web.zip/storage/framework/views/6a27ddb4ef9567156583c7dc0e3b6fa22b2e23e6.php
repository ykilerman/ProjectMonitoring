<?php $__env->startSection('title'); ?> contoh | <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php /* place your content here */ ?>
tes

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>