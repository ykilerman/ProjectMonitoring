<?php $__env->startSection('title'); ?> New Users | <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-default">
            <div class="panel-heading">
                New User
            </div>
            <div class="panel-body">
                <?php echo e(Form::open(['url' => url('user/create'),'method'=>'POST','id'=>'frmUserAdd','class'=>'form-horizontal'])); ?>

                    <?php if(count($errors) > 0): ?>
                        <div id="error" class="alert alert-danger">
                            <?php foreach($errors->all() as $error): ?>
                                <p><strong><?php echo e($error); ?></strong></p>
                            <?php endforeach; ?>
                            <p><i>Click to close the alert.</i></p>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <?php echo e(Form::label('username','Username',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('username',old('username'),['class'=>'form-control','placeholder'=>'Insert Username ...'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('password','Password',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::password('password',['class'=>'form-control'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('name','Name',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::text('name',old('name'),['class'=>'form-control','placeholder'=>'Insert Name ...'])); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('position','Position',['class'=>'col-sm-3 control-label'])); ?>

                        <div class="col-sm-9">
                            <?php echo e(Form::select('position',['Project Admin'=>'Project Admin','Project Coordinator'=>'Project Coordinator','Management'=>'Management','Stakeholder'=>'Stakeholder'],old('position'),['class'=>'form-control','placeholder'=>'Select Position ...'])); ?>

                        </div>
                    </div>
                    <div class="col-sm-offset-3 col-sm-2">
                        <?php echo e(Form::submit('Save',['class'=>'btn btn-primary btn-block','id'=>'btnSave'])); ?>

                    </div>
                    <div class="col-sm-2">
                        <a href="<?php echo e(url('user')); ?>" class="btn btn-info btn-block">Cancel</a>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>

<script>
    $("#error").click(function(){
        $(this).hide('slow');
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>