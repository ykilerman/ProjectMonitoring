<?php $__env->startSection('title'); ?> Projects | <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<meta name="_token" content="<?php echo csrf_token(); ?>" />
<h2>
    Project List
    <div class="pull-right">
        <button id="btnAdd" class="btn btn-lg btn-primary"><i class="glyphicon glyphicon-plus-sign"></i> New</button>
    </div>
</h2>
<hr>
<div id="new"></div>
<div class="row">
    <div class="col-lg-4 form-group">
        <div class="input-group">
            <input class="form-control" id="search" value="<?php echo e(Session::get('project_search')); ?>"
                   onkeyup="if ((event.keyCode >= 65 && event.keyCode <= 90) || event.keyCode == 13 || event.keyCode == 8 || event.keyCode == 46) ajaxLoad('<?php echo e(url('project/list')); ?>?ok=1&search='+this.value,'data')"
                   placeholder="Find name ..."
                   type="text"
                   autofocus>
            <div class="input-group-btn">
                <button type="button" class="btn btn-default"
                        onclick="ajaxLoad('<?php echo e(url('project/list')); ?>?ok=1&search='+$('#search').val())"><i
                            class="glyphicon glyphicon-search"></i>
                </button>
            </div>
        </div>
    </div>
</div>
<div id="data"></div>
<hr>

<script>
$("#new").hide();
$(document).ready(function(){
    ajaxLoad("<?php echo e(url('project/list')); ?>",'data');
    $("#btnAdd").click(function(e){
        e.preventDefault();
        $(".loading").show();
        $("#new").load('<?php echo e(url('project/create')); ?>',function(){
            $(".loading").hide();
            $("#new").fadeIn('slow');
        });
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>