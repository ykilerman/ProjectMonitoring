<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Requests\ProjectCreateRequest;
use App\Project;
use App\User;
use Auth;
use Input;
use Redirect;
use Session;

class ProjectController extends Controller
{
    public function getIndex()
    {
        if(Auth::user()->position == 'Project Admin' || Auth::user()->position == 'Project Coordinator')
        {
            return view('project.admin_read');
        }
        else
        {
            return view('project.stakeholder_read');
        }
    }
    public function getList()
    {
        Session::put('project_search', Input::has('ok') ? Input::get('search') : (Session::has('project_search') ? Session::get('project_search') : ''));
        Session::put('project_field', Input::has('field') ? Input::get('field') : (Session::has('project_field') ? Session::get('project_field') : 'name'));
        Session::put('project_sort', Input::has('sort') ? Input::get('sort') : (Session::has('project_sort') ? Session::get('project_sort') : 'asc'));
        $projects = Project::where('name', 'like', '%' . Session::get('project_search') . '%')
            ->orderBy(Session::get('project_field'), Session::get('project_sort'))
            ->paginate(6);
        $total = Project::where('name', 'like', '%' . Session::get('project_search') . '%')
            ->count();
        return view('project.admin_list')
            ->with('projects',$projects)
            ->with('total',$total);
    }
    public function getCreate()
    {
        return view('project.admin_create');
    }
    public function postCreate(Request $request, ProjectCreateRequest $valid)
    {
        if($valid)
        {
            if($request->hasFile('icon_path') && $request->file('icon_path')->isValid())
            {
                Project::create([
                    'name' => Input::get('name'),
                    'user_id' => Input::get('user_id'),
                    'icon_path' => 'image/evidence/'.Input::get('name').'.jpg',
                    'description' => Input::get('description'),
                    'client_name' => Input::get('client_name'),
                    'value' => Input::get('value'),
                    'update_schedule' => Input::get('update_schedule'),
                ]);
                Storage::put(
                    'image/evidence/'.Input::get('name').'.jpg',
                    base64_encode(file_get_contents($request->file('icon_path')->getRealPath()))
                );
            }
            return "Project " . Input::get('name') . " is created.";
        }
    }
    public function getUserlistselect()
    {
        $users = User::orderBy('name','asc')->get();
        return view('project.userListSelect')
            ->with('users',$users);
    }
}
